import numpy as np

# rewards = [1, 3, 5] 
# discount_factor = 0.99

# length = len(rewards)
# discounted_rewards = np.zeros(length)
# discounted_rewards[length-1] += rewards[length-1]

# for i in reversed(range(length-1)):
#     print(i)
#     discounted_rewards[i] = rewards[i] + discount_factor*discounted_rewards[i+1]
# print(discounted_rewards)

