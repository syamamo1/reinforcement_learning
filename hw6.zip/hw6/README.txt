HW6 

REINFORCE 
2:45 train time
395.1 best average reward

REINFORCE w/ Baseline
2:40 train time
467.66 best average reward